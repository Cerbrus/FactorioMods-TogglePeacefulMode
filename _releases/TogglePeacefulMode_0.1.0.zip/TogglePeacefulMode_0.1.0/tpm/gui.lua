if not tpm then error("Dependency missing: tpm core") end

tpm.gui = {}

require "gui.layout"
require "gui.events"
